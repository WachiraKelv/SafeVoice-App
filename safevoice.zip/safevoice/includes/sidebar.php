<div class="sidebar">
    <div class="sidebar-header">
        <div class="sidebar-logo">
            <i class="fas fa-shield-heart"></i>
        </div>
        <h4 class="sidebar-title">SafeVoice</h4>
        <p class="sidebar-subtitle">Support System</p>
    </div>
    
    <div class="sidebar-menu">
        <?php if(isSurvivor()): ?>
            <div class="nav flex-column">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>" href="dashboard.php">
                    <div class="nav-icon">
                        <i class="fas fa-tachometer-alt"></i>
                    </div>
                    <div class="nav-text">Dashboard</div>
                </a>
                <a class="nav-link <?php echo (strpos($_SERVER['PHP_SELF'], 'reporting.php') !== false && isset($_GET['action']) && $_GET['action'] == 'create') ? 'active' : ''; ?>" href="reporting.php?action=create">
                    <div class="nav-icon">
                        <i class="fas fa-flag"></i>
                    </div>
                    <div class="nav-text">Report Incident</div>
                </a>
                <a class="nav-link <?php echo (strpos($_SERVER['PHP_SELF'], 'reporting.php') !== false && isset($_GET['action']) && $_GET['action'] == 'view') ? 'active' : ''; ?>" href="reporting.php?action=view">
                    <div class="nav-icon">
                        <i class="fas fa-list"></i>
                    </div>
                    <div class="nav-text">My Reports</div>
                </a>
                <a class="nav-link sos-nav <?php echo (strpos($_SERVER['PHP_SELF'], 'reporting.php') !== false && isset($_GET['action']) && $_GET['action'] == 'sos') ? 'active' : ''; ?>" href="reporting.php?action=sos">
                    <div class="nav-icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div class="nav-text">SOS Alert</div>
                    <?php 
                    $stmt = $pdo->prepare("SELECT COUNT(*) FROM sos_alerts WHERE user_id = ? AND status = 'Active'");
                    $stmt->execute([$_SESSION['user_id']]);
                    $active_count = $stmt->fetchColumn();
                    if($active_count > 0): ?>
                        <span class="nav-badge"><?php echo $active_count; ?></span>
                    <?php endif; ?>
                </a>
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'support_services.php' ? 'active' : ''; ?>" href="support_services.php?action=list">
                    <div class="nav-icon">
                        <i class="fas fa-hand-holding-heart"></i>
                    </div>
                    <div class="nav-text">Support Services</div>
                </a>
            </div>
            
        <?php elseif(isResponder()): ?>
            <div class="nav flex-column">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>" href="dashboard.php">
                    <div class="nav-icon">
                        <i class="fas fa-tachometer-alt"></i>
                    </div>
                    <div class="nav-text">Dashboard</div>
                    <?php 
                    $stmt = $pdo->prepare("SELECT COUNT(*) FROM sos_alerts WHERE status = 'Active'");
                    $stmt->execute();
                    $active_sos = $stmt->fetchColumn();
                    if($active_sos > 0): ?>
                        <span class="nav-badge emergency"><?php echo $active_sos; ?></span>
                    <?php endif; ?>
                </a>
                <a class="nav-link <?php echo (strpos($_SERVER['PHP_SELF'], 'reporting.php') !== false && isset($_GET['action']) && $_GET['action'] == 'view') ? 'active' : ''; ?>" href="reporting.php?action=view">
                    <div class="nav-icon">
                        <i class="fas fa-tasks"></i>
                    </div>
                    <div class="nav-text">Assigned Cases</div>
                </a>
                <a class="nav-link sos-nav <?php echo (strpos($_SERVER['PHP_SELF'], 'reporting.php') !== false && isset($_GET['action']) && $_GET['action'] == 'sos') ? 'active' : ''; ?>" href="reporting.php?action=sos">
                    <div class="nav-icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div class="nav-text">SOS Alerts</div>
                    <?php if($active_sos > 0): ?>
                        <span class="nav-badge emergency pulse"><?php echo $active_sos; ?></span>
                    <?php endif; ?>
                </a>
            </div>
            
        <?php elseif(isAdmin()): ?>
            <div class="nav flex-column">
                <a class="nav-link <?php echo strpos($_SERVER['PHP_SELF'], 'admin.php') !== false && isset($_GET['action']) && $_GET['action'] == 'reports' ? 'active' : ''; ?>" href="admin.php?action=reports">
                    <div class="nav-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="nav-text">Dashboard</div>
                    <?php 
                    $stmt = $pdo->prepare("SELECT COUNT(*) FROM sos_alerts WHERE status = 'Active'");
                    $stmt->execute();
                    $active_sos = $stmt->fetchColumn();
                    if($active_sos > 0): ?>
                        <span class="nav-badge emergency"><?php echo $active_sos; ?></span>
                    <?php endif; ?>
                </a>
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'user_management.php' ? 'active' : ''; ?>" href="user_management.php?action=list">
                    <div class="nav-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="nav-text">Users</div>
                </a>
                <a class="nav-link" href="admin.php?action=reports">
                    <div class="nav-icon">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="nav-text">Reports</div>
                </a>
                <a class="nav-link" href="admin.php?action=responders">
                    <div class="nav-icon">
                        <i class="fas fa-user-md"></i>
                    </div>
                    <div class="nav-text">Responders</div>
                </a>
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'support_services.php' ? 'active' : ''; ?>" href="support_services.php?action=list">
                    <div class="nav-icon">
                        <i class="fas fa-building"></i>
                    </div>
                    <div class="nav-text">Services</div>
                </a>
                <a class="nav-link" href="admin.php?action=analytics">
                    <div class="nav-icon">
                        <i class="fas fa-chart-bar"></i>
                    </div>
                    <div class="nav-text">Analytics</div>
                </a>
            
            </div>
        <?php endif; ?>
    </div>
    
    <div class="sidebar-footer">
        <div class="sidebar-status">
            <div class="status-indicator"></div>
            <span>System Online</span>
        </div>
        <div class="sidebar-version">
            <i class="fas fa-shield-alt"></i> v2.0
        </div>
    </div>
</div>

<style>
    .sidebar {
        background: rgba(31, 41, 55, 0.95);
        backdrop-filter: blur(20px);
        min-height: calc(100vh - 70px);
        border-radius: 24px;
        margin: 20px 0;
        padding: 0;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        display: flex;
        flex-direction: column;
        position: sticky;
        top: 90px;
        overflow: hidden;
        border: 1px solid rgba(99, 102, 241, 0.1);
    }
    
    .sidebar-header {
        background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
        padding: 25px 20px;
        text-align: center;
        color: white;
    }
    
    .sidebar-logo {
        width: 60px;
        height: 60px;
        background: rgba(255, 255, 255, 0.2);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 15px;
        animation: float 3s ease-in-out infinite;
    }
    
    .sidebar-logo i {
        font-size: 2rem;
    }
    
    .sidebar-title {
        font-size: 1.3rem;
        font-weight: 700;
        margin-bottom: 5px;
    }
    
    .sidebar-subtitle {
        font-size: 0.75rem;
        opacity: 0.9;
        margin-bottom: 0;
    }
    
    .sidebar-menu {
        flex: 1;
        padding: 20px;
    }
    
    .sidebar-menu .nav-link {
        display: flex;
        align-items: center;
        padding: 12px 16px;
        margin: 8px 0;
        border-radius: 12px;
        color: #e5e7eb;
        transition: all 0.3s;
        position: relative;
        overflow: hidden;
        gap: 12px;
    }
    
    .sidebar-menu .nav-link::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(99, 102, 241, 0.2), transparent);
        transition: left 0.5s;
    }
    
    .sidebar-menu .nav-link:hover::before {
        left: 100%;
    }
    
    .sidebar-menu .nav-link:hover {
        background: rgba(99, 102, 241, 0.15);
        transform: translateX(5px);
    }
    
    .sidebar-menu .nav-link.active {
        background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
        color: white;
        box-shadow: 0 4px 12px rgba(99, 102, 241, 0.4);
    }
    
    .sidebar-menu .nav-link.active .nav-icon i {
        color: white;
    }
    
    .nav-icon {
        width: 32px;
        text-align: center;
    }
    
    .nav-icon i {
        font-size: 1.2rem;
        color: #a78bfa;
        transition: all 0.3s;
    }
    
    .nav-text {
        flex: 1;
        font-weight: 500;
        font-size: 0.95rem;
    }
    
    .nav-badge {
        background: #ef4444;
        color: white;
        border-radius: 20px;
        padding: 2px 8px;
        font-size: 0.7rem;
        font-weight: 600;
        animation: pulse 1.5s infinite;
    }
    
    .nav-badge.emergency {
        background: #dc2626;
        animation: pulse 1s infinite;
    }
    
    .sos-nav {
        background: rgba(239, 68, 68, 0.1);
        border: 1px solid rgba(239, 68, 68, 0.3);
    }
    
    .sos-nav .nav-icon i {
        color: #f87171;
    }
    
    .sos-nav.active {
        background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
    }
    
    .sos-nav.active .nav-icon i {
        color: white;
    }
    
    .sidebar-footer {
        padding: 20px;
        border-top: 1px solid rgba(75, 85, 99, 0.5);
        background: rgba(15, 23, 42, 0.8);
    }
    
    .sidebar-status {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 0.8rem;
        color: #10b981;
        margin-bottom: 10px;
    }
    
    .status-indicator {
        width: 8px;
        height: 8px;
        background: #10b981;
        border-radius: 50%;
        animation: pulse 2s infinite;
        box-shadow: 0 0 5px #10b981;
    }
    
    .sidebar-version {
        font-size: 0.7rem;
        color: #9ca3af;
        text-align: center;
    }
    
    @keyframes float {
        0%, 100% {
            transform: translateY(0);
        }
        50% {
            transform: translateY(-5px);
        }
    }
    
    @keyframes pulse {
        0%, 100% {
            opacity: 1;
            transform: scale(1);
        }
        50% {
            opacity: 0.7;
            transform: scale(1.05);
        }
    }
    
    @media (max-width: 768px) {
        .sidebar {
            min-height: auto;
            position: relative;
            top: 0;
            margin: 10px;
        }
        
        .sidebar-menu .nav-link {
            padding: 10px 12px;
        }
        
        .nav-text {
            font-size: 0.85rem;
        }
        
        .sidebar-header {
            padding: 20px 15px;
        }
        
        .sidebar-logo {
            width: 45px;
            height: 45px;
        }
        
        .sidebar-logo i {
            font-size: 1.5rem;
        }
        
        .sidebar-title {
            font-size: 1.1rem;
        }
    }
</style>