<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="index.php">
            <div class="brand-icon">
                <i class="fas fa-shield-heart"></i>
            </div>
            <div class="brand-text">
                <strong>SafeVoice</strong>
                <span class="brand-tagline">Your Safe Space</span>
            </div>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <?php if(isLoggedIn()): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle user-menu" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                            <div class="user-avatar">
                                <i class="fas fa-user-circle"></i>
                            </div>
                            <div class="user-info">
                                <span class="user-name"><?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                                <span class="user-role"><?php echo ucfirst($_SESSION['user_role']); ?></span>
                            </div>
                            <?php if(getUnreadCount($_SESSION['user_id']) > 0): ?>
                                <span class="notification-badge"><?php echo getUnreadCount($_SESSION['user_id']); ?></span>
                            <?php endif; ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="user_management.php?action=profile">
                                <i class="fas fa-user-circle"></i> My Profile
                            </a></li>
                            <li><a class="dropdown-item" href="user_management.php?action=contacts">
                                <i class="fas fa-address-book"></i> Trusted Contacts
                            </a></li>
                            <li><a class="dropdown-item" href="#">
                                <i class="fas fa-bell"></i> Notifications
                                <?php if(getUnreadCount($_SESSION['user_id']) > 0): ?>
                                    <span class="badge bg-danger"><?php echo getUnreadCount($_SESSION['user_id']); ?></span>
                                <?php endif; ?>
                            </a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="logout.php">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a></li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link btn-login" href="login.php">
                            <i class="fas fa-sign-in-alt"></i>
                            <span>Login</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn-register" href="register.php">
                            <i class="fas fa-user-plus"></i>
                            <span>Register</span>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<style>
    .navbar {
        background: rgba(15, 23, 42, 0.95);
        backdrop-filter: blur(20px);
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
        padding: 0.8rem 0;
        position: sticky;
        top: 0;
        z-index: 1000;
        border-bottom: 1px solid rgba(99, 102, 241, 0.1);
    }
    
    .navbar-brand {
        display: flex;
        align-items: center;
        gap: 12px;
        text-decoration: none;
    }
    
    .brand-icon {
        width: 45px;
        height: 45px;
        background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 4px 10px rgba(99, 102, 241, 0.3);
    }
    
    .brand-icon i {
        font-size: 1.5rem;
        color: white;
    }
    
    .brand-text {
        display: flex;
        flex-direction: column;
    }
    
    .brand-text strong {
        font-size: 1.3rem;
        background: linear-gradient(135deg, #a78bfa 0%, #c084fc 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        letter-spacing: -0.5px;
    }
    
    .brand-tagline {
        font-size: 0.7rem;
        color: #9ca3af;
        letter-spacing: 0.5px;
    }
    
    .user-menu {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 8px 16px !important;
        border-radius: 50px !important;
        background: rgba(99, 102, 241, 0.1);
        transition: all 0.3s;
    }
    
    .user-menu:hover {
        background: rgba(99, 102, 241, 0.2);
        transform: translateY(-2px);
    }
    
    .user-avatar {
        width: 40px;
        height: 40px;
        background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .user-avatar i {
        font-size: 1.3rem;
        color: white;
    }
    
    .user-info {
        display: flex;
        flex-direction: column;
    }
    
    .user-name {
        font-weight: 600;
        color: #f3f4f6;
        font-size: 0.9rem;
    }
    
    .user-role {
        font-size: 0.7rem;
        color: #a78bfa;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .notification-badge {
        position: absolute;
        top: 5px;
        right: 5px;
        background: #ef4444;
        color: white;
        border-radius: 50%;
        width: 20px;
        height: 20px;
        font-size: 0.7rem;
        display: flex;
        align-items: center;
        justify-content: center;
        animation: pulse 1.5s infinite;
    }
    
    .btn-login, .btn-register {
        border-radius: 50px !important;
        padding: 8px 24px !important;
        margin: 0 5px;
        transition: all 0.3s;
        font-weight: 500;
    }
    
    .btn-login {
        background: transparent;
        color: #a78bfa;
        border: 2px solid #a78bfa;
    }
    
    .btn-login:hover {
        background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
        color: white;
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
        border-color: transparent;
    }
    
    .btn-register {
        background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
        color: white;
    }
    
    .btn-register:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(99, 102, 241, 0.4);
    }
    
    .dropdown-menu {
        border: none;
        border-radius: 16px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        padding: 8px;
        margin-top: 10px;
        background: rgba(31, 41, 55, 0.98);
        backdrop-filter: blur(10px);
    }
    
    .dropdown-item {
        border-radius: 12px;
        padding: 10px 20px;
        transition: all 0.3s;
        display: flex;
        align-items: center;
        gap: 10px;
        color: #e5e7eb;
    }
    
    .dropdown-item i {
        width: 20px;
        color: #a78bfa;
    }
    
    .dropdown-item:hover {
        background: linear-gradient(135deg, rgba(99, 102, 241, 0.2) 0%, rgba(139, 92, 246, 0.2) 100%);
        transform: translateX(5px);
        color: white;
    }
    
    .dropdown-divider {
        border-top: 1px solid rgba(75, 85, 99, 0.5);
    }
    
    .navbar-toggler {
        border: none;
        background: rgba(99, 102, 241, 0.2);
    }
    
    .navbar-toggler-icon {
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(167, 139, 250, 1)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
    }
    
    @keyframes pulse {
        0%, 100% {
            transform: scale(1);
        }
        50% {
            transform: scale(1.1);
        }
    }
    
    @media (max-width: 768px) {
        .user-info {
            display: none;
        }
        
        .brand-tagline {
            display: none;
        }
        
        .btn-login, .btn-register {
            padding: 6px 16px !important;
            font-size: 0.9rem;
        }
        
        .brand-icon {
            width: 35px;
            height: 35px;
        }
        
        .brand-icon i {
            font-size: 1.2rem;
        }
        
        .brand-text strong {
            font-size: 1.1rem;
        }
    }
</style>