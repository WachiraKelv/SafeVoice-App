<?php
require_once 'config/functions.php';
requireLogin();

$action = isset($_GET['action']) ? $_GET['action'] : 'create';
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

if ($action == 'sos' && $_SERVER['REQUEST_METHOD'] == 'POST' && isSurvivor()) {
    header('Content-Type: application/json');
    $lat = $_POST['lat'];
    $lng = $_POST['lng'];
    $address = isset($_POST['address']) ? $_POST['address'] : '';
    $result = sendSOS($user_id, $lat, $lng, $address);
    echo json_encode(['success' => $result]);
    exit();
}

if ($action == 'create' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $location = '';
    
    if (!empty($_POST['latitude']) && !empty($_POST['longitude'])) {
        $location = sanitizeInput($_POST['address']) ?: 
                   "Lat: " . $_POST['latitude'] . ", Lng: " . $_POST['longitude'];
    } else {
        $location = sanitizeInput($_POST['location']);
    }
    
    $data = [
        'user_id' => $user_id,
        'title' => sanitizeInput($_POST['title']),
        'category' => $_POST['category'],
        'description' => sanitizeInput($_POST['description']),
        'incident_date' => $_POST['incident_date'],
        'location' => $location,
        'is_anonymous' => isset($_POST['is_anonymous']) ? 1 : 0
    ];
    
    $report_id = createReport($data);
    
    if ($report_id && isset($_FILES['evidence']) && $_FILES['evidence']['error'] == 0) {
        uploadEvidence($report_id, $_FILES['evidence']);
    }
    
    addNotification($user_id, "Report Submitted", "Your report has been submitted successfully. We will review it shortly.", 'success');
    redirect('reporting.php?action=view');
}

if ($action == 'update' && $_SERVER['REQUEST_METHOD'] == 'POST' && isset($_GET['id'])) {
    $report_id = $_GET['id'];
    $update_text = sanitizeInput($_POST['update_text']);
    $status = $_POST['status'];
    
    updateReportStatus($report_id, $status, $_SESSION['user_id']);
    addCaseUpdate($report_id, $user_id, $update_text, $status);
    $report = getReport($report_id);
    if ($report && $report['user_id']) {
        addNotification($report['user_id'], "Case Update", "Your report #$report_id has been updated.", 'info');
    }
    redirect('reporting.php?action=details&id=' . $report_id);
}

if ($action == 'delete' && isset($_GET['id']) && (isAdmin() || isResponder())) {
    $report_id = $_GET['id'];
    global $pdo;
    
    try {
        $pdo->beginTransaction();
        
        $stmt = $pdo->prepare("DELETE FROM evidence WHERE report_id = ?");
        $stmt->execute([$report_id]);
        
        $stmt = $pdo->prepare("DELETE FROM case_updates WHERE report_id = ?");
        $stmt->execute([$report_id]);
        
        $stmt = $pdo->prepare("DELETE FROM reports WHERE id = ?");
        $stmt->execute([$report_id]);
        
        $pdo->commit();
        redirect('reporting.php?action=view&msg=deleted');
    } catch (Exception $e) {
        $pdo->rollBack();
        redirect('reporting.php?action=view&error=delete_failed');
    }
}

if ($action == 'resolve_sos' && isset($_GET['id']) && (isAdmin() || isResponder())) {
    $sos_id = $_GET['id'];
    resolveSOS($sos_id, $user_id);
    
    global $pdo;
    $stmt = $pdo->prepare("SELECT user_id FROM sos_alerts WHERE id = ?");
    $stmt->execute([$sos_id]);
    $survivor_id = $stmt->fetchColumn();
    
    if ($survivor_id) {
        addNotification($survivor_id, "SOS Resolved", "Your SOS alert has been marked as resolved. You are safe now.", 'success');
    }
    
    addNotification($user_id, "SOS Resolved", "You have resolved an SOS alert.", 'success');
    redirect('reporting.php?action=sos');
}
?>
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-3">
            <?php include 'includes/sidebar.php'; ?>
        </div>
        <div class="col-md-9">
            <div class="content-wrapper">
                <?php if(isset($_GET['msg']) && $_GET['msg'] == 'deleted'): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="fas fa-check-circle"></i> Report deleted successfully!
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if($action == 'sos' && isResponder()): ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card mb-4">
                                <div class="card-header bg-danger text-white">
                                    <h5 class="mb-0"><i class="fas fa-exclamation-triangle me-2 animate-pulse"></i> Active SOS Alerts - Emergency Response</h5>
                                </div>
                                <div class="card-body">
                                    <div class="alert alert-warning">
                                        <i class="fas fa-bell me-2"></i> 
                                        <strong>Attention Responder:</strong> These are active emergency alerts requiring immediate attention.
                                    </div>
                                    
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead class="table-dark">
                                                <tr>
                                                    <th>ID</th>
                                                    <th>Survivor Name</th>
                                                    <th>Phone</th>
                                                    <th>Location Coordinates</th>
                                                    <th>Alert Time</th>
                                                    <th>Status</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                global $pdo;
                                                $stmt = $pdo->prepare("SELECT s.*, u.full_name, u.phone FROM sos_alerts s JOIN users u ON s.user_id = u.id WHERE s.status = 'Active' ORDER BY s.created_at DESC");
                                                $stmt->execute();
                                                $active_sos = $stmt->fetchAll();
                                                ?>
                                                <?php if(count($active_sos) > 0): ?>
                                                    <?php foreach($active_sos as $sos): ?>
                                                    <tr class="table-danger">
                                                        <td>
                                                            <span class="badge bg-danger" style="font-size: 1rem;">#<?php echo $sos['id']; ?></span>
                                                        </td>
                                                        <td>
                                                            <strong><?php echo htmlspecialchars($sos['full_name']); ?></strong>
                                                            <br>
                                                            <small class="text-muted">ID: <?php echo $sos['user_id']; ?></small>
                                                        </td>
                                                        <td><?php echo htmlspecialchars($sos['phone']); ?></td>
                                                        <td>
                                                            <?php if($sos['latitude'] && $sos['longitude']): ?>
                                                                <div class="btn-group" role="group">
                                                                    <button class="btn btn-sm btn-info" onclick="showResponderSOSMap(<?php echo $sos['latitude']; ?>, <?php echo $sos['longitude']; ?>, '<?php echo htmlspecialchars($sos['full_name']); ?>')">
                                                                        <i class="fas fa-map-marker-alt"></i> View Map
                                                                    </button>
                                                                    <button class="btn btn-sm btn-secondary" onclick="copyCoordinates(<?php echo $sos['latitude']; ?>, <?php echo $sos['longitude']; ?>)">
                                                                        <i class="fas fa-copy"></i> Copy
                                                                    </button>
                                                                </div>
                                                                <br>
                                                                <small class="text-muted mt-1">
                                                                    <i class="fas fa-location-dot"></i> Lat: <?php echo $sos['latitude']; ?>, Lng: <?php echo $sos['longitude']; ?>
                                                                </small>
                                                            <?php else: ?>
                                                                <span class="text-muted">No coordinates available</span>
                                                                <br>
                                                                <small>Phone location tracking needed</small>
                                                            <?php endif; ?>
                                                         </td>
                                                        <td><?php echo date('M d, Y H:i:s', strtotime($sos['created_at'])); ?>
                                                            <br>
                                                            <small class="text-muted"><?php echo time_elapsed_string($sos['created_at']); ?></small>
                                                         </td>
                                                        <td>
                                                            <span class="badge bg-danger animate-pulse" style="font-size: 0.9rem;">
                                                                <i class="fas fa-circle"></i> ACTIVE
                                                            </span>
                                                         </td>
                                                        <td>
                                                            <div class="btn-group-vertical" role="group">
                                                                <button class="btn btn-sm btn-success mb-1" onclick="resolveSOSAlert(<?php echo $sos['id']; ?>, '<?php echo htmlspecialchars($sos['full_name']); ?>')">
                                                                    <i class="fas fa-check-circle"></i> Mark Resolved
                                                                </button>
                                                                <?php if($sos['location_address']): ?>
                                                                    <button class="btn btn-sm btn-info" onclick="showAddress('<?php echo htmlspecialchars($sos['location_address']); ?>')">
                                                                        <i class="fas fa-address-card"></i> Show Address
                                                                    </button>
                                                                <?php endif; ?>
                                                            </div>
                                                         </td>
                                                     </tr>
                                                    <?php endforeach; ?>
                                                <?php else: ?>
                                                    <tr>
                                                        <td colspan="7" class="text-center">
                                                            <div class="alert alert-success mb-0">
                                                                <i class="fas fa-check-circle"></i> No active SOS alerts. All survivors are safe!
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="mb-0"><i class="fas fa-history me-2"></i> Resolved SOS Alerts History</h5>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>ID</th>
                                                    <th>Survivor</th>
                                                    <th>Location</th>
                                                    <th>Alert Time</th>
                                                    <th>Resolved By</th>
                                                    <th>Resolved At</th>
                                                    <th>Response Time</th>
                                                 </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $stmt = $pdo->prepare("SELECT s.*, u.full_name as survivor_name, r.full_name as resolver_name 
                                                    FROM sos_alerts s 
                                                    JOIN users u ON s.user_id = u.id 
                                                    LEFT JOIN users r ON s.resolved_by = r.id 
                                                    WHERE s.status = 'Resolved' 
                                                    ORDER BY s.resolved_at DESC LIMIT 50");
                                                $stmt->execute();
                                                $resolved_sos = $stmt->fetchAll();
                                                ?>
                                                <?php foreach($resolved_sos as $sos): ?>
                                                <tr>
                                                    <td>#<?php echo $sos['id']; ?></td>
                                                    <td><?php echo htmlspecialchars($sos['survivor_name']); ?></td>
                                                    <td>
                                                        <?php if($sos['latitude'] && $sos['longitude']): ?>
                                                            <button class="btn btn-sm btn-outline-info" onclick="showResponderSOSMap(<?php echo $sos['latitude']; ?>, <?php echo $sos['longitude']; ?>, '<?php echo htmlspecialchars($sos['survivor_name']); ?>')">
                                                                <i class="fas fa-map-marker-alt"></i> View
                                                            </button>
                                                        <?php else: ?>
                                                            Not specified
                                                        <?php endif; ?>
                                                     </td>
                                                    <td><?php echo date('M d, Y H:i', strtotime($sos['created_at'])); ?></td>
                                                    <td><?php echo htmlspecialchars($sos['resolver_name'] ?: 'System'); ?></td>
                                                    <td><?php echo date('M d, Y H:i', strtotime($sos['resolved_at'])); ?></td>
                                                    <td>
                                                        <?php 
                                                        $alert_time = strtotime($sos['created_at']);
                                                        $resolve_time = strtotime($sos['resolved_at']);
                                                        $response_minutes = round(($resolve_time - $alert_time) / 60);
                                                        echo $response_minutes . ' minutes';
                                                        ?>
                                                     </td>
                                                </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal fade" id="responderSOSMapModal" tabindex="-1">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header bg-danger text-white">
                                    <h5 class="modal-title"><i class="fas fa-map-marker-alt me-2"></i> SOS Alert Location - Emergency Response</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <div id="responderSOSMapView" style="height: 400px;"></div>
                                    <div id="sosAddressDisplay" class="alert alert-info mt-2" style="display: none;"></div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="button" class="btn btn-primary" onclick="openGoogleMaps()">
                                        <i class="fas fa-external-link-alt"></i> Open in Google Maps
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <script>
                        let currentMapLat = null;
                        let currentMapLng = null;
                        let responderMap = null;
                        
                        function showResponderSOSMap(lat, lng, name) {
                            currentMapLat = lat;
                            currentMapLng = lng;
                            
                            if (responderMap) {
                                responderMap.remove();
                            }
                            
                            responderMap = L.map('responderSOSMapView').setView([lat, lng], 15);
                            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                                attribution: '© OpenStreetMap contributors'
                            }).addTo(responderMap);
                            
                            var marker = L.marker([lat, lng]).addTo(responderMap)
                                .bindPopup('<b>SOS Alert from ' + name + '</b><br>Time: ' + new Date().toLocaleString())
                                .openPopup();
                            
                            L.circle([lat, lng], {
                                color: 'red',
                                fillColor: '#f03',
                                fillOpacity: 0.2,
                                radius: 100
                            }).addTo(responderMap);
                            
                            setTimeout(function() {
                                responderMap.invalidateSize();
                            }, 100);
                            
                            var modal = new bootstrap.Modal(document.getElementById('responderSOSMapModal'));
                            modal.show();
                        }
                        
                        function openGoogleMaps() {
                            if (currentMapLat && currentMapLng) {
                                window.open(`https://www.google.com/maps?q=${currentMapLat},${currentMapLng}`, '_blank');
                            }
                        }
                        
                        function copyCoordinates(lat, lng) {
                            navigator.clipboard.writeText(`${lat}, ${lng}`);
                            alert('Coordinates copied to clipboard!');
                        }
                        
                        function showAddress(address) {
                            document.getElementById('sosAddressDisplay').innerHTML = '<i class="fas fa-location-dot"></i> ' + address;
                            document.getElementById('sosAddressDisplay').style.display = 'block';
                            setTimeout(function() {
                                document.getElementById('sosAddressDisplay').style.display = 'none';
                            }, 5000);
                        }
                        
                        function resolveSOSAlert(sosId, survivorName) {
                            if (confirm('⚠️ CONFIRM RESOLVE SOS ALERT\n\nSurvivor: ' + survivorName + '\n\nOnly mark as resolved when:\n✓ The survivor is safe\n✓ Emergency services have arrived\n✓ The situation is under control\n\nThis will notify the survivor that help has arrived.')) {
                                window.location.href = 'reporting.php?action=resolve_sos&id=' + sosId;
                            }
                        }
                    </script>
                    
                <?php elseif($action == 'sos' && isSurvivor()): ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card mb-4">
                                <div class="card-header bg-danger text-white">
                                    <h5 class="mb-0"><i class="fas fa-exclamation-triangle me-2"></i> Emergency SOS Alert</h5>
                                </div>
                                <div class="card-body text-center">
                                    <div class="alert alert-warning">
                                        <i class="fas fa-shield-alt me-2"></i>
                                        <strong>Your Safety is Our Priority</strong> - Only use this in real emergencies.
                                    </div>
                                    <p class="lead">If you are in immediate danger, click the SOS button below to send an emergency alert.</p>
                                    <button class="btn btn-danger btn-lg" id="sosButton" style="padding: 15px 40px; font-size: 1.5rem;">
                                        <i class="fas fa-exclamation-triangle me-2"></i> SEND SOS ALERT
                                    </button>
                                    <p class="text-muted mt-3">
                                        <i class="fas fa-info-circle"></i> Your location will be shared with emergency responders and your trusted contacts.
                                    </p>
                                </div>
                            </div>
                            
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="mb-0"><i class="fas fa-history me-2"></i> My SOS Alert History</h5>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead class="table-dark">
                                                <tr>
                                                    <th>ID</th>
                                                    <th>Date & Time</th>
                                                    <th>Location</th>
                                                    <th>Status</th>
                                                    <th>Resolved By</th>
                                                    <th>Resolved At</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                global $pdo;
                                                $stmt = $pdo->prepare("SELECT s.*, u.full_name as resolver_name FROM sos_alerts s LEFT JOIN users u ON s.resolved_by = u.id WHERE s.user_id = ? ORDER BY s.created_at DESC");
                                                $stmt->execute([$user_id]);
                                                $sos_alerts = $stmt->fetchAll();
                                                ?>
                                                <?php if(count($sos_alerts) > 0): ?>
                                                    <?php foreach($sos_alerts as $alert): ?>
                                                    <tr>
                                                        <td>#<?php echo $alert['id']; ?></td>
                                                        <td><?php echo date('M d, Y H:i:s', strtotime($alert['created_at'])); ?></td>
                                                        <td>
                                                            <?php if($alert['latitude'] && $alert['longitude']): ?>
                                                                <button class="btn btn-sm btn-info" onclick="showSOSLocation(<?php echo $alert['latitude']; ?>, <?php echo $alert['longitude']; ?>)">
                                                                    <i class="fas fa-map-marker-alt"></i> View Location
                                                                </button>
                                                                <br>
                                                                <small class="text-muted">
                                                                    Lat: <?php echo $alert['latitude']; ?>, 
                                                                    Lng: <?php echo $alert['longitude']; ?>
                                                                </small>
                                                            <?php else: ?>
                                                                <span class="text-muted">Location not captured</span>
                                                            <?php endif; ?>
                                                         </td>
                                                        <td>
                                                            <span class="badge bg-<?php echo $alert['status'] == 'Active' ? 'danger animate-pulse' : 'success'; ?>">
                                                                <?php echo $alert['status']; ?>
                                                            </span>
                                                         </td>
                                                        <td><?php echo $alert['resolver_name'] ?: 'Not yet resolved'; ?></td>
                                                        <td><?php echo $alert['resolved_at'] ? date('M d, Y H:i', strtotime($alert['resolved_at'])) : '-'; ?></td>
                                                        <td>
                                                            <?php if($alert['status'] == 'Active'): ?>
                                                                <span class="badge bg-warning">Active - Help En Route</span>
                                                            <?php else: ?>
                                                                <span class="badge bg-success">Resolved - You're Safe</span>
                                                            <?php endif; ?>
                                                         </td>
                                                    </tr>
                                                    <?php endforeach; ?>
                                                <?php else: ?>
                                                    <tr>
                                                        <td colspan="7" class="text-center">
                                                            <div class="alert alert-info mb-0">
                                                                <i class="fas fa-info-circle"></i> No SOS alerts triggered yet. You're safe!
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal fade" id="sosConfirmModal" tabindex="-1">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header bg-danger text-white">
                                    <h5 class="modal-title"><i class="fas fa-exclamation-triangle me-2"></i>Confirm SOS Alert</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <p>⚠️ <strong>WARNING:</strong> This will send an emergency alert to:</p>
                                    <ul>
                                        <li>Emergency Responders</li>
                                        <li>System Administrators</li>
                                        <li>Your Trusted Contacts</li>
                                    </ul>
                                    <p>Your current location will be shared.</p>
                                    <div id="sosLocationStatus" class="alert alert-info">
                                        <i class="fas fa-spinner fa-spin me-2"></i> Getting your location...
                                    </div>
                                    <p class="text-danger mt-2"><small>Only use this in real emergencies!</small></p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                    <button type="button" class="btn btn-danger" id="confirmSOSButton">Confirm & Send SOS</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal fade" id="sosLocationModal" tabindex="-1">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Your SOS Alert Location</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <div id="sosLocationMap" style="height: 400px;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <script>
                        let currentLocation = null;
                        
                        document.getElementById('sosButton').addEventListener('click', function() {
                            if (navigator.geolocation) {
                                navigator.geolocation.getCurrentPosition(function(position) {
                                    currentLocation = {
                                        lat: position.coords.latitude,
                                        lng: position.coords.longitude
                                    };
                                    document.getElementById('sosLocationStatus').innerHTML = 
                                        '<i class="fas fa-check-circle me-2"></i> Location captured: ' + 
                                        currentLocation.lat.toFixed(6) + ', ' + currentLocation.lng.toFixed(6);
                                    document.getElementById('sosLocationStatus').className = 'alert alert-success';
                                    
                                    var sosModal = new bootstrap.Modal(document.getElementById('sosConfirmModal'));
                                    sosModal.show();
                                }, function(error) {
                                    document.getElementById('sosLocationStatus').innerHTML = 
                                        '<i class="fas fa-exclamation-circle me-2"></i> Unable to get location. Please enable location services.';
                                    document.getElementById('sosLocationStatus').className = 'alert alert-warning';
                                    
                                    var sosModal = new bootstrap.Modal(document.getElementById('sosConfirmModal'));
                                    sosModal.show();
                                });
                            } else {
                                document.getElementById('sosLocationStatus').innerHTML = 
                                    'Geolocation is not supported by your browser';
                                var sosModal = new bootstrap.Modal(document.getElementById('sosConfirmModal'));
                                sosModal.show();
                            }
                        });
                        
                        document.getElementById('confirmSOSButton').addEventListener('click', function() {
                            let lat = currentLocation ? currentLocation.lat : 0;
                            let lng = currentLocation ? currentLocation.lng : 0;
                            
                            fetch('reporting.php?action=sos', {
                                method: 'POST',
                                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                                body: 'lat=' + lat + '&lng=' + lng
                            }).then(response => response.json()).then(data => {
                                if (data.success) {
                                    alert('✅ SOS Alert Sent Successfully!\n\nHelp has been notified and is on the way.\nYour trusted contacts have also been alerted.\n\nStay safe!');
                                    location.reload();
                                } else {
                                    alert('❌ Failed to send SOS alert. Please try again or call emergency services immediately.');
                                }
                            }).catch(error => {
                                alert('Error sending SOS. Please call emergency services immediately.\nPolice: 911');
                            });
                        });
                        
                        function showSOSLocation(lat, lng) {
                            var map = L.map('sosLocationMap').setView([lat, lng], 15);
                            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                                attribution: '© OpenStreetMap contributors'
                            }).addTo(map);
                            L.marker([lat, lng]).addTo(map)
                                .bindPopup('<b>Your SOS Alert Location</b><br>Time: ' + new Date().toLocaleString())
                                .openPopup();
                            
                            var sosModal = new bootstrap.Modal(document.getElementById('sosLocationModal'));
                            sosModal.show();
                            
                            setTimeout(function() {
                                map.invalidateSize();
                            }, 100);
                        }
                    </script>
                    
                <?php elseif($action == 'create'): ?>
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Report an Incident</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" enctype="multipart/form-data" id="reportForm">
                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <label>Title</label>
                                        <input type="text" name="title" class="form-control" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label>Category</label>
                                        <select name="category" class="form-select" required>
                                            <option value="Physical Violence">Physical Violence</option>
                                            <option value="Sexual Violence">Sexual Violence</option>
                                            <option value="Domestic Violence">Domestic Violence</option>
                                            <option value="Emotional Abuse">Emotional Abuse</option>
                                            <option value="Child Abuse">Child Abuse</option>
                                            <option value="Cyber Harassment">Cyber Harassment</option>
                                            <option value="Other">Other</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label>Incident Date</label>
                                        <input type="date" name="incident_date" class="form-control" required>
                                    </div>
                                    
                                    <div class="col-md-12 mb-3">
                                        <label>Location Method</label>
                                        <div class="btn-group w-100" role="group">
                                            <input type="radio" class="btn-check" name="location_method" id="text_location" value="text" checked>
                                            <label class="btn btn-outline-primary" for="text_location">Enter Address</label>
                                            
                                            <input type="radio" class="btn-check" name="location_method" id="map_location" value="map">
                                            <label class="btn btn-outline-primary" for="map_location">Select on Map</label>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-12 mb-3" id="textLocationDiv">
                                        <label>Location (Address)</label>
                                        <input type="text" name="location" class="form-control" placeholder="City, Area, or specific location">
                                    </div>
                                    
                                    <div class="col-md-12 mb-3" id="mapLocationDiv" style="display: none;">
                                        <label>Select Location on Map</label>
                                        <div id="locationMap" class="map-container" style="height: 400px; margin-bottom: 15px;"></div>
                                        
                                        <div class="row">
                                            <div class="col-md-6 mb-2">
                                                <label>Latitude</label>
                                                <input type="text" name="latitude" id="latitude" class="form-control" readonly placeholder="Click on map">
                                            </div>
                                            <div class="col-md-6 mb-2">
                                                <label>Longitude</label>
                                                <input type="text" name="longitude" id="longitude" class="form-control" readonly placeholder="Click on map">
                                            </div>
                                            <div class="col-md-12 mb-2">
                                                <label>Address (Auto-detected)</label>
                                                <input type="text" name="address" id="address" class="form-control" readonly placeholder="Address will appear here">
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-12 mb-3">
                                        <label>Description</label>
                                        <textarea name="description" rows="5" class="form-control" required></textarea>
                                    </div>
                                    <div class="col-md-12 mb-3">
                                        <label>Upload Evidence (Optional)</label>
                                        <input type="file" name="evidence" class="form-control" accept=".jpg,.jpeg,.png,.pdf,.mp4,.docx">
                                        <small class="text-muted">Supported: JPG, PNG, PDF, MP4, DOCX</small>
                                    </div>
                                    <div class="col-md-12 mb-3 form-check">
                                        <input type="checkbox" name="is_anonymous" class="form-check-input" id="anonymous">
                                        <label class="form-check-label" for="anonymous">Submit Anonymously</label>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary">Submit Report</button>
                            </form>
                        </div>
                    </div>
                    
                    <script>
                        let map;
                        let marker;
                        
                        document.querySelectorAll('input[name="location_method"]').forEach(radio => {
                            radio.addEventListener('change', function() {
                                if (this.value === 'text') {
                                    document.getElementById('textLocationDiv').style.display = 'block';
                                    document.getElementById('mapLocationDiv').style.display = 'none';
                                } else {
                                    document.getElementById('textLocationDiv').style.display = 'none';
                                    document.getElementById('mapLocationDiv').style.display = 'block';
                                    if (!map) {
                                        initMap();
                                    }
                                }
                            });
                        });
                        
                        function initMap() {
                            const defaultLat = 40.7128;
                            const defaultLng = -74.0060;
                            
                            map = L.map('locationMap').setView([defaultLat, defaultLng], 13);
                            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                                attribution: '© OpenStreetMap contributors'
                            }).addTo(map);
                            
                            map.on('click', function(e) {
                                const lat = e.latlng.lat;
                                const lng = e.latlng.lng;
                                
                                document.getElementById('latitude').value = lat;
                                document.getElementById('longitude').value = lng;
                                
                                if (marker) {
                                    map.removeLayer(marker);
                                }
                                
                                marker = L.marker([lat, lng]).addTo(map);
                                marker.bindPopup(`Selected Location<br>Lat: ${lat}<br>Lng: ${lng}`).openPopup();
                                reverseGeocode(lat, lng);
                            });
                        }
                        
                        function reverseGeocode(lat, lng) {
                            const url = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`;
                            fetch(url)
                                .then(response => response.json())
                                .then(data => {
                                    if (data.display_name) {
                                        document.getElementById('address').value = data.display_name;
                                    }
                                })
                                .catch(error => console.error('Geocoding error:', error));
                        }
                    </script>
                    
                <?php elseif($action == 'view'): ?>
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">My Reports</h5>
                            <a href="?action=create" class="btn btn-primary btn-sm">
                                <i class="fas fa-plus"></i> New Report
                            </a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead class="table-dark">
                                        <tr>
                                            <th>ID</th><th>Title</th><th>Category</th><th>Status</th><th>Date</th><th>Location</th><th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $reports = getReports($user_id); ?>
                                        <?php if(count($reports) > 0): ?>
                                            <?php foreach($reports as $report): ?>
                                            <tr>
                                                <td>#<?php echo $report['id']; ?></td>
                                                <td><?php echo htmlspecialchars($report['title']); ?></td>
                                                <td><?php echo $report['category']; ?></td>
                                                <td>
                                                    <span class="badge bg-<?php 
                                                        echo $report['status'] == 'Resolved' ? 'success' : 
                                                            ($report['status'] == 'Pending' ? 'warning' : 'info'); 
                                                    ?>">
                                                        <?php echo $report['status']; ?>
                                                    </span>
                                                </td>
                                                <td><?php echo date('M d, Y', strtotime($report['created_at'])); ?></td>
                                                <td><?php echo htmlspecialchars(substr($report['location'], 0, 30)) ?: 'Not specified'; ?></td>
                                                <td>
                                                    <a href="?action=details&id=<?php echo $report['id']; ?>" class="btn btn-sm btn-info">
                                                        <i class="fas fa-eye"></i> View
                                                    </a>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr><td colspan="7" class="text-center">No reports found. <a href="?action=create">Create your first report</a></td></tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                <?php elseif($action == 'details' && isset($_GET['id'])): ?>
                    <?php $report = getReport($_GET['id']); ?>
                    <?php if($report && ($report['user_id'] == $user_id || isAdmin() || isResponder())): ?>
                        <div class="row">
                            <div class="col-md-8">
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <h5 class="mb-0">Report #<?php echo $report['id']; ?>: <?php echo htmlspecialchars($report['title']); ?></h5>
                                    </div>
                                    <div class="card-body">
                                        <p><strong>Category:</strong> <?php echo $report['category']; ?></p>
                                        <p><strong>Status:</strong> 
                                            <span class="badge bg-<?php 
                                                echo $report['status'] == 'Resolved' ? 'success' : 
                                                    ($report['status'] == 'Pending' ? 'warning' : 'info'); 
                                            ?>">
                                                <?php echo $report['status']; ?>
                                            </span>
                                        </p>
                                        <p><strong>Incident Date:</strong> <?php echo date('F d, Y', strtotime($report['incident_date'])); ?></p>
                                        <p><strong>Location:</strong> <?php echo htmlspecialchars($report['location']) ?: 'Not specified'; ?></p>
                                        <p><strong>Description:</strong></p>
                                        <p><?php echo nl2br(htmlspecialchars($report['description'])); ?></p>
                                        
                                        <?php $evidence = getEvidence($report['id']); ?>
                                        <?php if(count($evidence) > 0): ?>
                                            <h6>Evidence:</h6>
                                            <ul>
                                                <?php foreach($evidence as $item): ?>
                                                <li><a href="../assets/uploads/<?php echo $item['file_path']; ?>" target="_blank"><?php echo htmlspecialchars($item['file_name']); ?></a></li>
                                                <?php endforeach; ?>
                                            </ul>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <?php $updates = getCaseUpdates($report['id']); ?>
                                <?php if(count($updates) > 0): ?>
                                    <div class="card">
                                        <div class="card-header">
                                            <h5 class="mb-0">Case Timeline</h5>
                                        </div>
                                        <div class="card-body">
                                            <?php foreach($updates as $update): ?>
                                            <div class="mb-3 pb-3 border-bottom">
                                                <strong><?php echo htmlspecialchars($update['updater_name']); ?></strong> 
                                                <small class="text-muted">- <?php echo date('M d, Y H:i', strtotime($update['created_at'])); ?></small>
                                                <p class="mb-0 mt-2"><?php echo nl2br(htmlspecialchars($update['update_text'])); ?></p>
                                                <?php if($update['status_change']): ?>
                                                    <span class="badge bg-info mt-2">Status changed to: <?php echo $update['status_change']; ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="col-md-4">
                                <?php if(isResponder() || isAdmin()): ?>
                                    <div class="card mb-4">
                                        <div class="card-header">
                                            <h6 class="mb-0">Update Case</h6>
                                        </div>
                                        <div class="card-body">
                                            <form method="POST" action="?action=update&id=<?php echo $report['id']; ?>">
                                                <div class="mb-3">
                                                    <label>Status</label>
                                                    <select name="status" class="form-select">
                                                        <option value="Pending">Pending</option>
                                                        <option value="Under Review">Under Review</option>
                                                        <option value="Assigned">Assigned</option>
                                                        <option value="Investigating">Investigating</option>
                                                        <option value="Resolved">Resolved</option>
                                                        <option value="Closed">Closed</option>
                                                    </select>
                                                </div>
                                                <div class="mb-3">
                                                    <label>Update Notes</label>
                                                    <textarea name="update_text" rows="3" class="form-control" required></textarea>
                                                </div>
                                                <button type="submit" class="btn btn-primary w-100">Update Case</button>
                                            </form>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if($report['assigned_responder_id']): ?>
                                    <?php $responder = getUser($report['assigned_responder_id']); ?>
                                    <div class="card">
                                        <div class="card-header">
                                            <h6 class="mb-0">Assigned Responder</h6>
                                        </div>
                                        <div class="card-body">
                                            <p><strong>Name:</strong> <?php echo htmlspecialchars($responder['full_name']); ?></p>
                                            <p><strong>Email:</strong> <?php echo htmlspecialchars($responder['email']); ?></p>
                                            <p><strong>Phone:</strong> <?php echo htmlspecialchars($responder['phone']); ?></p>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-danger">Report not found or you don't have permission to view it.</div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php 
function time_elapsed_string($datetime) {
    $now = new DateTime();
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);
    
    if ($diff->i < 1) return 'Just now';
    if ($diff->i < 60) return $diff->i . ' minute' . ($diff->i > 1 ? 's' : '') . ' ago';
    if ($diff->h < 24) return $diff->h . ' hour' . ($diff->h > 1 ? 's' : '') . ' ago';
    return $diff->d . ' day' . ($diff->d > 1 ? 's' : '') . ' ago';
}

include 'includes/footer.php'; 
?>