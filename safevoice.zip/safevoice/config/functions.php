<?php
require_once 'database.php';

function loginUser($email, $password) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND is_active = 1");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['full_name'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['user_email'] = $user['email'];
        return true;
    }
    return false;
}

function registerUser($data) {
    global $pdo;
    $hashed_password = password_hash($data['password'], PASSWORD_DEFAULT);
    
    $stmt = $pdo->prepare("INSERT INTO users (full_name, email, phone, gender, password, role) VALUES (?, ?, ?, ?, ?, 'survivor')");
    return $stmt->execute([$data['full_name'], $data['email'], $data['phone'], $data['gender'], $hashed_password]);
}

function logoutUser() {
    session_destroy();
    redirect('login.php');
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

function isResponder() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'responder';
}

function isSurvivor() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'survivor';
}

function requireLogin() {
    if (!isLoggedIn()) {
        redirect('login.php');
    }
}

function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        redirect('dashboard.php');
    }
}

function getUsers($role = null) {
    global $pdo;
    if ($role) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE role = ? ORDER BY created_at DESC");
        $stmt->execute([$role]);
    } else {
        $stmt = $pdo->query("SELECT * FROM users ORDER BY created_at DESC");
    }
    return $stmt->fetchAll();
}

function getUser($id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function updateUser($id, $data) {
    global $pdo;
    $stmt = $pdo->prepare("UPDATE users SET full_name = ?, email = ?, phone = ? WHERE id = ?");
    return $stmt->execute([$data['full_name'], $data['email'], $data['phone'], $id]);
}

function changePassword($id, $new_password) {
    global $pdo;
    $hashed = password_hash($new_password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
    return $stmt->execute([$hashed, $id]);
}

function toggleUserStatus($id) {
    global $pdo;
    $user = getUser($id);
    if ($user) {
        $new_status = $user['is_active'] ? 0 : 1;
        $stmt = $pdo->prepare("UPDATE users SET is_active = ? WHERE id = ?");
        return $stmt->execute([$new_status, $id]);
    }
    return false;
}

function deleteUser($id) {
    global $pdo;
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND role = 'survivor'");
    return $stmt->execute([$id]);
}

function getTrustedContacts($user_id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM trusted_contacts WHERE user_id = ? ORDER BY created_at DESC");
    $stmt->execute([$user_id]);
    return $stmt->fetchAll();
}

function addTrustedContact($user_id, $data) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO trusted_contacts (user_id, name, relationship, phone, email) VALUES (?, ?, ?, ?, ?)");
    return $stmt->execute([$user_id, $data['name'], $data['relationship'], $data['phone'], $data['email']]);
}

function deleteTrustedContact($id, $user_id) {
    global $pdo;
    $stmt = $pdo->prepare("DELETE FROM trusted_contacts WHERE id = ? AND user_id = ?");
    return $stmt->execute([$id, $user_id]);
}

function createReport($data) {
    global $pdo;
    $user_id = isset($data['user_id']) ? $data['user_id'] : null;
    $stmt = $pdo->prepare("INSERT INTO reports (user_id, title, category, description, incident_date, location, is_anonymous) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $result = $stmt->execute([$user_id, $data['title'], $data['category'], $data['description'], $data['incident_date'], $data['location'], $data['is_anonymous']]);
    
    if ($result) {
        return $pdo->lastInsertId();
    }
    return false;
}

function getReports($user_id = null, $status = null) {
    global $pdo;
    $sql = "SELECT r.*, u.full_name as reporter_name FROM reports r LEFT JOIN users u ON r.user_id = u.id";
    $conditions = [];
    $params = [];
    
    if ($user_id) {
        $conditions[] = "r.user_id = ?";
        $params[] = $user_id;
    }
    
    if ($status) {
        $conditions[] = "r.status = ?";
        $params[] = $status;
    }
    
    if (count($conditions) > 0) {
        $sql .= " WHERE " . implode(" AND ", $conditions);
    }
    
    $sql .= " ORDER BY r.created_at DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function getReport($id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT r.*, u.full_name as reporter_name, u.email as reporter_email, u.phone as reporter_phone FROM reports r LEFT JOIN users u ON r.user_id = u.id WHERE r.id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function updateReportStatus($id, $status, $responder_id = null) {
    global $pdo;
    $stmt = $pdo->prepare("UPDATE reports SET status = ?, assigned_responder_id = ? WHERE id = ?");
    return $stmt->execute([$status, $responder_id, $id]);
}

function addCaseUpdate($report_id, $user_id, $update_text, $status_change = null) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO case_updates (report_id, updated_by, update_text, status_change) VALUES (?, ?, ?, ?)");
    return $stmt->execute([$report_id, $user_id, $update_text, $status_change]);
}

function getCaseUpdates($report_id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT cu.*, u.full_name as updater_name FROM case_updates cu LEFT JOIN users u ON cu.updated_by = u.id WHERE cu.report_id = ? ORDER BY cu.created_at DESC");
    $stmt->execute([$report_id]);
    return $stmt->fetchAll();
}

function uploadEvidence($report_id, $file) {
    global $pdo;
    $allowed = ['jpg', 'jpeg', 'png', 'pdf', 'mp4', 'docx'];
    $filename = $file['name'];
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    
    if (!in_array($ext, $allowed)) {
        return false;
    }
    
    $new_filename = time() . '_' . uniqid() . '.' . $ext;
    $upload_path = UPLOAD_PATH . $new_filename;
    
    if (move_uploaded_file($file['tmp_name'], $upload_path)) {
        $stmt = $pdo->prepare("INSERT INTO evidence (report_id, file_name, file_path, file_type) VALUES (?, ?, ?, ?)");
        return $stmt->execute([$report_id, $filename, $new_filename, $ext]);
    }
    return false;
}

function getEvidence($report_id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM evidence WHERE report_id = ? ORDER BY uploaded_at DESC");
    $stmt->execute([$report_id]);
    return $stmt->fetchAll();
}

function sendSOS($user_id, $latitude, $longitude, $address = null) {
    global $pdo;
    
    $stmt = $pdo->prepare("INSERT INTO sos_alerts (user_id, latitude, longitude, location_address) VALUES (?, ?, ?, ?)");
    $result = $stmt->execute([$user_id, $latitude, $longitude, $address]);
    
    if ($result) {
        $sos_id = $pdo->lastInsertId();
        
        addNotification(1, "New SOS Alert", "User has triggered an SOS alert. Please respond immediately.", 'danger');
        
        $contacts = getTrustedContacts($user_id);
        foreach ($contacts as $contact) {
            addNotification($user_id, "Emergency Alert", "Your trusted contact has triggered an SOS. Please check on them.", 'danger');
        }
        
        return $sos_id;
    }
    return false;
}

function getActiveSOS() {
    global $pdo;
    $stmt = $pdo->query("SELECT s.*, u.full_name, u.phone FROM sos_alerts s JOIN users u ON s.user_id = u.id WHERE s.status = 'Active' ORDER BY s.created_at DESC");
    return $stmt->fetchAll();
}

function resolveSOS($sos_id, $resolved_by) {
    global $pdo;
    $stmt = $pdo->prepare("UPDATE sos_alerts SET status = 'Resolved', resolved_by = ?, resolved_at = NOW() WHERE id = ?");
    return $stmt->execute([$resolved_by, $sos_id]);
}

function getServices($type = null) {
    global $pdo;
    if ($type) {
        $stmt = $pdo->prepare("SELECT * FROM services WHERE type = ? AND is_active = 1 ORDER BY name");
        $stmt->execute([$type]);
    } else {
        $stmt = $pdo->query("SELECT * FROM services WHERE is_active = 1 ORDER BY type, name");
    }
    return $stmt->fetchAll();
}

function addService($data) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO services (name, type, phone, address, latitude, longitude, operating_hours) VALUES (?, ?, ?, ?, ?, ?, ?)");
    return $stmt->execute([$data['name'], $data['type'], $data['phone'], $data['address'], $data['latitude'], $data['longitude'], $data['operating_hours']]);
}

function deleteService($id) {
    global $pdo;
    $stmt = $pdo->prepare("DELETE FROM services WHERE id = ?");
    return $stmt->execute([$id]);
}

function addNotification($user_id, $title, $message, $type = 'info') {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)");
    return $stmt->execute([$user_id, $title, $message, $type]);
}

function getNotifications($user_id, $limit = 10) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ?");
    $stmt->execute([$user_id, $limit]);
    return $stmt->fetchAll();
}

function markNotificationRead($id) {
    global $pdo;
    $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE id = ?");
    return $stmt->execute([$id]);
}

function getUnreadCount($user_id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
    $stmt->execute([$user_id]);
    return $stmt->fetchColumn();
}

function sanitizeInput($input) {
    return htmlspecialchars(strip_tags(trim($input)));
}

function redirect($url) {
    header("Location: " . BASE_URL . $url);
    exit();
}

function getStatistics() {
    global $pdo;
    
    $stats = [];
    
    $stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'survivor'");
    $stats['total_survivors'] = $stmt->fetchColumn();
    
    $stmt = $pdo->query("SELECT COUNT(*) FROM reports");
    $stats['total_reports'] = $stmt->fetchColumn();
    
    $stmt = $pdo->query("SELECT COUNT(*) FROM sos_alerts WHERE status = 'Active'");
    $stats['active_sos'] = $stmt->fetchColumn();
    
    $stmt = $pdo->query("SELECT COUNT(*) FROM reports WHERE status = 'Resolved'");
    $stats['resolved_cases'] = $stmt->fetchColumn();
    
    $stmt = $pdo->query("SELECT category, COUNT(*) as count FROM reports GROUP BY category");
    $stats['reports_by_category'] = $stmt->fetchAll();
    
    $stmt = $pdo->query("SELECT DATE_FORMAT(created_at, '%Y-%m') as month, COUNT(*) as count FROM reports WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH) GROUP BY DATE_FORMAT(created_at, '%Y-%m') ORDER BY month");
    $stats['reports_by_month'] = $stmt->fetchAll();
    
    $stmt = $pdo->query("SELECT status, COUNT(*) as count FROM reports GROUP BY status");
    $stats['case_status'] = $stmt->fetchAll();
    
    return $stats;
}
?>