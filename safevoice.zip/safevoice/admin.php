<?php
require_once 'config/functions.php';
requireAdmin();

$action = isset($_GET['action']) ? $_GET['action'] : 'reports';
?>
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-3">
            <?php include 'includes/sidebar.php'; ?>
        </div>
        <div class="col-md-9">
            <div class="content-wrapper">
                <?php if($action == 'reports'): ?>
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Manage All Reports</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Reporter</th>
                                            <th>Title</th>
                                            <th>Category</th>
                                            <th>Status</th>
                                            <th>Date</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $reports = getReports(); ?>
                                        <?php foreach($reports as $report): ?>
                                        <tr>
                                            <td>#<?php echo $report['id']; ?></td>
                                            <td><?php echo $report['is_anonymous'] ? 'Anonymous' : htmlspecialchars($report['reporter_name']); ?></td>
                                            <td><?php echo htmlspecialchars($report['title']); ?></td>
                                            <td><?php echo $report['category']; ?></td>
                                            <td>
                                                <span class="badge bg-<?php 
                                                    echo $report['status'] == 'Resolved' ? 'success' : 
                                                        ($report['status'] == 'Pending' ? 'warning' : 'info'); 
                                                ?>">
                                                    <?php echo $report['status']; ?>
                                                </span>
                                            </td>
                                            <td><?php echo date('M d, Y', strtotime($report['created_at'])); ?></td>
                                            <td>
                                                <a href="reporting.php?action=details&id=<?php echo $report['id']; ?>" class="btn btn-sm btn-info">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                <?php elseif($action == 'responders'): ?>
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Manage Responders</h5>
                            <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addResponderModal">
                                <i class="fas fa-plus"></i> Add Responder
                            </button>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Organization</th>
                                            <th>Role</th>
                                            <th>Phone</th>
                                            <th>Status</th>
                                        </td>
                                    </thead>
                                    <tbody>
                                        <?php $responders = getUsers('responder'); ?>
                                        <?php foreach($responders as $responder): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($responder['full_name']); ?></td>
                                            <td><?php 
                                                $stmt = $pdo->prepare("SELECT organization FROM responders WHERE user_id = ?");
                                                $stmt->execute([$responder['id']]);
                                                echo htmlspecialchars($stmt->fetchColumn() ?: 'N/A');
                                            ?></td>
                                            <td><?php 
                                                $stmt = $pdo->prepare("SELECT responder_type FROM responders WHERE user_id = ?");
                                                $stmt->execute([$responder['id']]);
                                                echo htmlspecialchars($stmt->fetchColumn() ?: 'N/A');
                                            ?></td>
                                            <td><?php echo htmlspecialchars($responder['phone']); ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo $responder['is_active'] ? 'success' : 'danger'; ?>">
                                                    <?php echo $responder['is_active'] ? 'Active' : 'Inactive'; ?>
                                                </span>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal fade" id="addResponderModal" tabindex="-1">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <form method="POST" action="user_management.php?action=add">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Add New Responder</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="role" value="responder">
                                        <div class="mb-3">
                                            <label>Full Name</label>
                                            <input type="text" name="full_name" class="form-control" required>
                                        </div>
                                        <div class="mb-3">
                                            <label>Email</label>
                                            <input type="email" name="email" class="form-control" required>
                                        </div>
                                        <div class="mb-3">
                                            <label>Phone</label>
                                            <input type="tel" name="phone" class="form-control" required>
                                        </div>
                                        <div class="mb-3">
                                            <label>Password</label>
                                            <input type="password" name="password" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-primary">Add Responder</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                <?php elseif($action == 'analytics'): ?>
                    <?php $stats = getStatistics(); ?>
                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <div class="card">
                                <div class="card-header">Reports by Category</div>
                                <div class="card-body">
                                    <canvas id="categoryChart"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="card">
                                <div class="card-header">Reports by Month</div>
                                <div class="card-body">
                                    <canvas id="monthChart"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="card">
                                <div class="card-header">Case Status Distribution</div>
                                <div class="card-body">
                                    <canvas id="statusChart"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="card">
                                <div class="card-header">SOS Alert Trends</div>
                                <div class="card-body">
                                    <canvas id="sosChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <script>
                        new Chart(document.getElementById('categoryChart'), {
                            type: 'bar',
                            data: {
                                labels: <?php echo json_encode(array_column($stats['reports_by_category'], 'category')); ?>,
                                datasets: [{
                                    label: 'Number of Reports', 
                                    data: <?php echo json_encode(array_column($stats['reports_by_category'], 'count')); ?>, 
                                    backgroundColor: 'rgba(99, 102, 241, 0.6)'
                                }]
                            }
                        });
                        
                        new Chart(document.getElementById('monthChart'), {
                            type: 'line',
                            data: {
                                labels: <?php echo json_encode(array_column($stats['reports_by_month'], 'month')); ?>,
                                datasets: [{
                                    label: 'Reports', 
                                    data: <?php echo json_encode(array_column($stats['reports_by_month'], 'count')); ?>, 
                                    borderColor: '#8b5cf6',
                                    backgroundColor: 'rgba(139, 92, 246, 0.1)',
                                    tension: 0.4,
                                    fill: true
                                }]
                            }
                        });
                        
                        new Chart(document.getElementById('statusChart'), {
                            type: 'pie',
                            data: {
                                labels: <?php echo json_encode(array_column($stats['case_status'], 'status')); ?>,
                                datasets: [{
                                    data: <?php echo json_encode(array_column($stats['case_status'], 'count')); ?>, 
                                    backgroundColor: ['#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#6b21a5']
                                }]
                            }
                        });
                        
                        const sosCtx = document.getElementById('sosChart').getContext('2d');
                        new Chart(sosCtx, {
                            type: 'line',
                            data: {
                                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                                datasets: [{
                                    label: 'SOS Alerts',
                                    data: [12, 19, 15, 17, 14, 13],
                                    borderColor: '#ef4444',
                                    backgroundColor: 'rgba(239, 68, 68, 0.1)',
                                    tension: 0.4,
                                    fill: true
                                }]
                            }
                        });
                    </script>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>