-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 13, 2026 at 08:38 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `safevoice_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `case_updates`
--

CREATE TABLE `case_updates` (
  `id` int(11) NOT NULL,
  `report_id` int(11) NOT NULL,
  `updated_by` int(11) NOT NULL,
  `update_text` text NOT NULL,
  `status_change` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `evidence`
--

CREATE TABLE `evidence` (
  `id` int(11) NOT NULL,
  `report_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_type` varchar(50) DEFAULT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `type` enum('info','warning','success','danger') DEFAULT 'info',
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `title`, `message`, `type`, `is_read`, `created_at`) VALUES
(1, 1, 'New SOS Alert', 'User has triggered an SOS alert. Please respond immediately.', 'danger', 0, '2026-06-13 17:57:43'),
(2, 2, 'Emergency Alert', 'Your trusted contact has triggered an SOS. Please check on them.', 'danger', 0, '2026-06-13 17:57:43'),
(3, 2, 'Emergency Alert', 'Your trusted contact has triggered an SOS. Please check on them.', 'danger', 0, '2026-06-13 17:57:43');

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `category` enum('Physical Violence','Sexual Violence','Domestic Violence','Emotional Abuse','Child Abuse','Cyber Harassment','Other') NOT NULL,
  `description` text NOT NULL,
  `incident_date` date NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `is_anonymous` tinyint(1) DEFAULT 0,
  `status` enum('Pending','Under Review','Assigned','Investigating','Resolved','Closed') DEFAULT 'Pending',
  `assigned_responder_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `responders`
--

CREATE TABLE `responders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `organization` varchar(100) DEFAULT NULL,
  `responder_type` enum('Police Officer','Counselor','Hospital Staff','Shelter Staff','Legal Aid Officer') NOT NULL,
  `badge_number` varchar(50) DEFAULT NULL,
  `is_available` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` enum('Police Station','Hospital','Shelter','Counselor','Legal Aid') NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `operating_hours` varchar(200) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `name`, `type`, `phone`, `address`, `latitude`, `longitude`, `operating_hours`, `is_active`, `created_at`) VALUES
(1, 'Central Police Station', 'Police Station', '911', '123 Main St, City', 40.71280000, -74.00600000, NULL, 1, '2026-06-13 17:39:30'),
(2, 'City General Hospital', 'Hospital', '555-0123', '456 Health Ave, City', 40.71400000, -74.00700000, NULL, 1, '2026-06-13 17:39:30'),
(3, 'Hope Shelter', 'Shelter', '555-0456', '789 Safe St, City', 40.71500000, -74.00800000, NULL, 1, '2026-06-13 17:39:30'),
(4, 'Wellness Counseling Center', 'Counselor', '555-0789', '321 Peace Blvd, City', 40.71600000, -74.00900000, NULL, 1, '2026-06-13 17:39:30'),
(5, 'Legal Aid Society', 'Legal Aid', '555-1011', '654 Justice Way, City', 40.71700000, -74.01000000, NULL, 1, '2026-06-13 17:39:30'),
(6, 'Central Police Station', 'Police Station', '911', '123 Main St, City Center', 40.71280000, -74.00600000, NULL, 1, '2026-06-13 17:50:51'),
(7, 'City General Hospital', 'Hospital', '555-0123', '456 Health Ave, City', 40.71400000, -74.00700000, NULL, 1, '2026-06-13 17:50:51'),
(8, 'Hope Shelter', 'Shelter', '555-0456', '789 Safe St, City', 40.71500000, -74.00800000, NULL, 1, '2026-06-13 17:50:51'),
(9, 'Wellness Counseling Center', 'Counselor', '555-0789', '321 Peace Blvd, City', 40.71600000, -74.00900000, NULL, 1, '2026-06-13 17:50:51'),
(10, 'Legal Aid Society', 'Legal Aid', '555-1011', '654 Justice Way, City', 40.71700000, -74.01000000, NULL, 1, '2026-06-13 17:50:51'),
(11, 'f', 'Police Station', '67i797878797979', 'fgnfghtrhju7', 99.99999999, 999.99999999, '687utht', 1, '2026-06-13 18:04:14');

-- --------------------------------------------------------

--
-- Table structure for table `sos_alerts`
--

CREATE TABLE `sos_alerts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `location_address` varchar(500) DEFAULT NULL,
  `status` enum('Active','Resolved','False Alarm') DEFAULT 'Active',
  `resolved_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `resolved_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trusted_contacts`
--

CREATE TABLE `trusted_contacts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `relationship` varchar(50) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trusted_contacts`
--

INSERT INTO `trusted_contacts` (`id`, `user_id`, `name`, `relationship`, `phone`, `email`, `created_at`) VALUES
(1, 2, 'Mike Johnson', 'Brother', '5551112222', NULL, '2026-06-13 17:50:51'),
(2, 2, 'Lisa Johnson', 'Mother', '5553334444', NULL, '2026-06-13 17:50:51');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `gender` enum('Male','Female','Other','Prefer not to say') DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('survivor','admin','responder') DEFAULT 'survivor',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `phone`, `gender`, `password`, `role`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Admin User', 'admin@safevoice.com', '1234567890', 'Other', '$2y$10$fc.nuVAs16h51F6kjfIiyuUNGfwSdYXVJJzIKnx6Lgk4T4nvTlXoW', 'admin', 1, '2026-06-13 17:50:51', '2026-06-13 17:50:51'),
(2, 'Sarah Johnson', 'sarah@example.com', '9876543210', 'Female', '$2y$10$E2BJVNep9Da6f/yxyeQ4iOjFq5wrIjhCmPfaECbx3ameL9fx9wqny', 'survivor', 1, '2026-06-13 17:50:51', '2026-06-13 17:50:51'),
(3, 'John Smith', 'john@example.com', '5551234567', 'Male', '$2y$10$9j1GvpTl2aVS2QBgpLy4wuk2APkHjcZV3ooLEOZ/liRU47jfYNo3C', 'survivor', 1, '2026-06-13 17:50:51', '2026-06-13 17:50:51'),
(4, 'Dr. Emily Brown', 'responder@safevoice.com', '5559876543', 'Female', '$2y$10$Pi1bcqAg7xdZECGsYhASnOqgk.6KnnJrMQyDNgvnYCqPhFm70mR5W', 'responder', 1, '2026-06-13 17:50:51', '2026-06-13 17:50:51'),
(5, 'they', 'admnn@gmail.com', '899999999999', '', '$2y$10$KMdY5RAk4KImsK19UcB0uOe/02CwmTrBPy/Iaiun5kAXVPkwInHiq', 'responder', 0, '2026-06-13 18:05:33', '2026-06-13 18:05:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `case_updates`
--
ALTER TABLE `case_updates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `report_id` (`report_id`),
  ADD KEY `updated_by` (`updated_by`);

--
-- Indexes for table `evidence`
--
ALTER TABLE `evidence`
  ADD PRIMARY KEY (`id`),
  ADD KEY `report_id` (`report_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `assigned_responder_id` (`assigned_responder_id`);

--
-- Indexes for table `responders`
--
ALTER TABLE `responders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sos_alerts`
--
ALTER TABLE `sos_alerts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `resolved_by` (`resolved_by`);

--
-- Indexes for table `trusted_contacts`
--
ALTER TABLE `trusted_contacts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `case_updates`
--
ALTER TABLE `case_updates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `evidence`
--
ALTER TABLE `evidence`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `responders`
--
ALTER TABLE `responders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `sos_alerts`
--
ALTER TABLE `sos_alerts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `trusted_contacts`
--
ALTER TABLE `trusted_contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `case_updates`
--
ALTER TABLE `case_updates`
  ADD CONSTRAINT `case_updates_ibfk_1` FOREIGN KEY (`report_id`) REFERENCES `reports` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `case_updates_ibfk_2` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `evidence`
--
ALTER TABLE `evidence`
  ADD CONSTRAINT `evidence_ibfk_1` FOREIGN KEY (`report_id`) REFERENCES `reports` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `reports_ibfk_2` FOREIGN KEY (`assigned_responder_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `responders`
--
ALTER TABLE `responders`
  ADD CONSTRAINT `responders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `sos_alerts`
--
ALTER TABLE `sos_alerts`
  ADD CONSTRAINT `sos_alerts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sos_alerts_ibfk_2` FOREIGN KEY (`resolved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `trusted_contacts`
--
ALTER TABLE `trusted_contacts`
  ADD CONSTRAINT `trusted_contacts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
